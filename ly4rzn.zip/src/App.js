function Perfil() {
  return (
    <div>
    <h1>Bem vindo a mim!</h1>
    <h2>Me chamo Bruna Gonçalves de Moraes</h2>
    <p> Tenho 16 anos, estudo na etec Polivalente de Americana,
      quando passar quero me formar em pericia criminal e se possivel seguire na area em que curso.
        Nasci em sumaré, amo praia, tudo que envolva mar sou apaixonada, amo viagens... 
        Sou um pouco ecletica, escuto de tudo, mas amo um sertanejo. Sou uma pessoa muito de boa com as coisas, mas um pouco estressadakkk
        Amo a vida e acho que todos devemos viver ela com muita intesidade e de melhor sempre!</p>
    </div>
  );
}

export default function MyApp() {
  return (
    <div>
           <Perfil />
    </div>
  );
}
